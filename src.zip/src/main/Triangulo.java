package main;

public class Triangulo extends FormaGeometrica {
	
	public static void main(String[] args) {
		
		// atribuindo em mostraValores, os três tipos de dados (comprimento, base e altura)
		double[] mostraValores = {9, 7, 14};
		double ladoA = 9;
		double ladoB = 7;
		double ladoC = 14;
		
		// cálculo de área e perímetro do retângulo
   
		double calcularPerimetro = ladoA + ladoB + ladoC;
		double sp = calcularPerimetro / 2;
		double calcularArea = Math.sqrt((sp * (sp - ladoA) * (sp - ladoB) * (sp - ladoC)));
		
		// sistema para saída de dados   
				System.out.println("O valor de um lado do triângulo foi de: " + mostraValores[0]);
			    System.out.println("O valor de um lado do triângulo foi de: " + mostraValores[1]);	
			    System.out.println("O valor de um lado do triângulo foi de: " + mostraValores[2]);
				System.out.println("Área do triângulo: " + calcularArea);
				System.out.println("Perimetro do triângulo: " + calcularPerimetro);
		        }	
	
	
	@Override
	public void calcularArea() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calcularPerimetro() {
		// TODO Auto-generated method stub

	}

	@Override
	public void mostraValores() {
		// TODO Auto-generated method stub
  }
}
