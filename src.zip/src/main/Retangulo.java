package main;

public class Retangulo extends FormaGeometrica {
	
	public static void main(String[] args) {
		
		// atribuindo em mostraValores, os dois tipos de dados (comprimento e altura)
		double[] mostraValores = {5.0, 2.0};
		double ladoA = 5.0;
		double ladoB = 2.0;
		
           // cálculo de área e perímetro do retângulo
           // mostraValores[0] = ladoA -> (comprimento) = 5.0
    	   // mostraValores[1] = ladoB -> (altura) = 2.0
		   double calcularArea = ladoA * ladoB;
		   double calcularPerimetro = 2 * ladoA + 2 * ladoB;
		   
		// sistema para saída de dados   
		System.out.println("O valor do comprimento do retângulo foi de: " + mostraValores[0]);
	    System.out.println("O valor da altura do retângulo foi de: " + mostraValores[1]);	
		System.out.println("Área do retângulo: " + calcularArea);
		System.out.println("Perimetro do retângulo: " + calcularPerimetro);
        }	
	

@Override
public void calcularArea() {
// TODO Auto-generated method stub

	}

@Override
public void calcularPerimetro() {
// TODO Auto-generated method stub

	}

@Override
public void mostraValores() {
// TODO Auto-generated method stub

	}
}
