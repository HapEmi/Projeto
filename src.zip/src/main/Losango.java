package main;

public class Losango extends FormaGeometrica {
	public static void main(String[] args) {
		
		//atribuindo em mostraValores, os valores da diagonais, maior e menor.
		double [] mostraValores = {10, 5};
		double diagMa = 10;
		double diagMe = 5;
		
		//cálculo de área e perímetro do losango.
		double calcularArea = (diagMe * diagMa) / 2;
		double calcularPerimetro = 2 * Math.sqrt(diagMa * diagMa + diagMe * diagMe);
		
		//sistema para saída de dados
		
		System.out.println("O valor da diagonal maior foi de: " + mostraValores[0]);
		System.out.println("O valor da diagonal menor foi de: " + mostraValores[1]);
		System.out.println("A área do losango foi de: " + calcularArea);
		System.out.println("O perímetro do losango foi de: " + calcularPerimetro);
	}
		
	public void calcularArea() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calcularPerimetro() {
		// TODO Auto-generated method stub

	}

	@Override
	public void mostraValores() {
		// TODO Auto-generated method stub

	}
}
