package main;

public class Trapezio extends FormaGeometrica {
	public static void main(String[] args) {
	
	//atribuindo em mostraValores, os valores das bases, menor e maior, os dois lados que existem, e mais a altura.
	double [] mostraValores = {10, 5, 6, 5, 4};
	double baseMa = 10;
	double baseMe = 5;
	double altura = 6;
	double ladoA = 5;
	double ladoB = 4;
	
	//cálculo de área e perímetro do trapézio.
	double calcularArea = altura / 2 * (baseMa + baseMe);
	double calcularPerimetro = baseMa + baseMe + ladoA + ladoB;
	
	//sistema para saída de dados.
	
	System.out.println("O valor da base maior foi de: " + mostraValores[0]);
	System.out.println("O valor da base menor foi de: " + mostraValores[1]);
	System.out.println("O valor da altura foi de: " + mostraValores[2]);
	System.out.println("O valor de um dos lados do trapézio foi de: " + mostraValores[3]);
	System.out.println("O valor de um dos lados do trapézio foi de: " + mostraValores[4]);
	System.out.println("A área do trapézio foi de: " + calcularArea);
	System.out.println("O perímetro do trapézio foi de: " + calcularPerimetro);
	
	
	
	
	}
	public void calcularArea() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calcularPerimetro() {
		// TODO Auto-generated method stub

	}

	@Override
	public void mostraValores() {
		// TODO Auto-generated method stub

	}
}
