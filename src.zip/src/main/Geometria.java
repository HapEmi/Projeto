package main;
public interface Geometria {
	double PI = 3.1415; 

    public void calcularArea();
    public void calcularPerimetro();
    public void mostraValores();
    
}

