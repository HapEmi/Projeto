package main;

public class Circulo extends FormaGeometrica {
	public static void main(String[] args) {
    double mostraValores = 5.0;
    double raio = 5.0;
    
    double calcularArea = PI * raio;
    double calcularPerimetro = 2 * PI * raio;
    
    System.out.println("Área do círculo: " + calcularArea);
    System.out.println("Perímetro do círculo: " + calcularPerimetro);
    System.out.println("O valor do raio do círculo foi de: " + mostraValores);  
    } 
	
	@Override
	public void calcularArea() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calcularPerimetro() {
		// TODO Auto-generated method stub

	}

	@Override
	public void mostraValores() {
		// TODO Auto-generated method stub

	}
}


