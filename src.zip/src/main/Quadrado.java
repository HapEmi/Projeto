package main;
public class Quadrado extends FormaGeometrica {
	public static void main(String[] args) {
        double mostraValores = 5.0;
        double lado = 5.0;
        
        double calcularArea = lado * lado; 
        double calcularPerimetro = 4 * lado;
        
        System.out.println("Área do quadrado: " + calcularArea);
        System.out.println("Perímetro do quadrado: " + calcularPerimetro);
        System.out.println("O valor do lado do quadrado foi de: " + mostraValores);
	}

	@Override
	public void calcularArea() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calcularPerimetro() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mostraValores() {
		// TODO Auto-generated method stub
		
	}
}

